//
//  UILabel+YZDeleteLine.h
//  suanfa
//
//  Created by 韩云智 on 2017/7/11.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (YZDeleteLine)

- (void)drawDeleteLineRange:(NSRange)range;
- (void)drawDeleteLineRange:(NSRange)range color:(UIColor *)color;

@end
