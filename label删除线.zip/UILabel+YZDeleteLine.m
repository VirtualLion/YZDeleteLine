//
//  UILabel+YZDeleteLine.m
//  suanfa
//
//  Created by 韩云智 on 2017/7/11.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "UILabel+YZDeleteLine.h"

@interface UILabel ()


@end

@implementation UILabel(YZDeleteLine)

- (void)drawDeleteLineRange:(NSRange)range {
    [self drawDeleteLineRange:range color:self.textColor];
}

- (void)drawDeleteLineRange:(NSRange)range color:(UIColor *)color{
    CGSize sizeBegin = [[self.text substringToIndex:range.location ] sizeWithAttributes:@{NSFontAttributeName:self.font}];
    CGSize sizeLine = [[self.text substringWithRange:range] sizeWithAttributes:@{NSFontAttributeName:self.font}];
    
    if (sizeBegin.width<self.bounds.size.width) {
        CALayer * deleteLine = [CALayer layer];
        deleteLine.frame = CGRectMake(sizeBegin.width, CGRectGetHeight(self.frame)/2, MIN(sizeLine.width, self.bounds.size.width-sizeBegin.width), 0.5);
        deleteLine.backgroundColor = color.CGColor;
        [self.layer addSublayer:deleteLine];
    }
}


@end
